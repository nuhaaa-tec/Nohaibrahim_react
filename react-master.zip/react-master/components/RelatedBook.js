import React from 'react'

function RelatedBook() {
  return (
    <div>RelatedBook</div>
  )
}

export default RelatedBook