import React from 'react'

function AddNewBook() {
  return (
    <div>AddNewBook</div>
  )
}

export default AddNewBook